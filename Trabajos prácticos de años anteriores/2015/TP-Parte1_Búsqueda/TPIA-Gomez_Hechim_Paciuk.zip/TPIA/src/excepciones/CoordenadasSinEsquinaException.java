package excepciones;

public class CoordenadasSinEsquinaException extends Exception {

	private static final long serialVersionUID = 6942998692066095650L;

}
