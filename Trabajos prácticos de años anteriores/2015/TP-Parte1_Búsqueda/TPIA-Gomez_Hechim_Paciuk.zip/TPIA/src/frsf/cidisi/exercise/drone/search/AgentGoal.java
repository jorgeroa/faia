

package frsf.cidisi.exercise.drone.search;

import interfaz.VentanaPrincipal;
import frsf.cidisi.faia.agent.search.GoalTest;
import frsf.cidisi.faia.state.AgentState;

public class AgentGoal extends GoalTest {

    @Override
    public boolean isGoalState (AgentState agentState) {
    
        if  (((DroneAgentState) agentState).getvictimariosEncontrados() == 1
        		|| ((DroneAgentState) agentState).getciudad().getVisitada()){
            return true;
        }
        return false;
	}
}