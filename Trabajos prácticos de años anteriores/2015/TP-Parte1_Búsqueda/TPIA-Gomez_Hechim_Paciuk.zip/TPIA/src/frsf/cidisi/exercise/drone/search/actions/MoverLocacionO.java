package frsf.cidisi.exercise.drone.search.actions;

import interfaz.VentanaPrincipal;
import logica.Esquina;
import logica.Locacion;
import frsf.cidisi.exercise.drone.search.*;
import frsf.cidisi.faia.agent.search.SearchAction;
import frsf.cidisi.faia.agent.search.SearchBasedAgentState;
import frsf.cidisi.faia.state.AgentState;
import frsf.cidisi.faia.state.EnvironmentState;

public class MoverLocacionO extends SearchAction {

	private int COSTO_MOVERSE = 1;
	
    /**
     * This method updates a tree node state when the search process is running.
     * It does not updates the real world state.
     */
    @Override
    public SearchBasedAgentState execute(SearchBasedAgentState s) {
        DroneAgentState agState = (DroneAgentState) s;
        
        if(agState.getlocacion().getAdyacente(Locacion.OESTE) != null 
        		&& ((agState.getlocacion().getAdyacente(Locacion.OESTE).getSenial() > 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= COSTO_MOVERSE)
     		   || (agState.getlocacion().getAdyacente(Locacion.OESTE).getSenial() == 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= 2*COSTO_MOVERSE))
        		&& !agState.getlocacion().getPadre().getVisitada()
        		&& agState.getlocacion().getAdyacente(Locacion.OESTE).getPasadas() < 1){
        	agState.setlocacion(agState.getlocacion().getAdyacente(Locacion.OESTE));
        	int costo = COSTO_MOVERSE;
        	if(agState.getlocacion().getSenial()==0)
        		costo *= 2;
        	agState.setenergiaGastada(agState.getenergiaGastada()+costo);
        	agState.getlocacion().increasePasadas();
        	if(agState.getlocacion() instanceof Esquina)
        		agState.getlocacion().setVisitada(true);
        	else if(agState.getlocacion().getSenial() == 0)
        		agState.getlocacion().setVisitada(true);
        	return agState;
        }
        
        return null;
    }

    /**
     * This method updates the agent state and the real world state.
     */
    @Override
    public EnvironmentState execute(AgentState ast, EnvironmentState est) {
        DroneEnvironmentState environmentState = (DroneEnvironmentState) est;
        DroneAgentState agState = ((DroneAgentState) ast);

        if(agState.getlocacion().getAdyacente(Locacion.OESTE) != null 
        		&& ((agState.getlocacion().getAdyacente(Locacion.OESTE).getSenial() > 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= COSTO_MOVERSE)
      		   || (agState.getlocacion().getAdyacente(Locacion.OESTE).getSenial() == 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= 2*COSTO_MOVERSE))){
        	agState.setlocacion(agState.getlocacion().getAdyacente(Locacion.OESTE));
        	int costo = COSTO_MOVERSE;
        	if(agState.getlocacion().getSenial()==0)
        		costo *= 2;
        	agState.setenergiaGastada(agState.getenergiaGastada()+costo);
        	agState.getlocacion().increasePasadas();
        	if(agState.getlocacion() instanceof Esquina)
        		agState.getlocacion().setVisitada(true);
        	else if(agState.getlocacion().getSenial() == 0)
        		agState.getlocacion().setVisitada(true);
        	
        	environmentState.setlocacionDrone(environmentState.getlocacionDrone().getAdyacente(Locacion.OESTE));
        	environmentState.setEnergiaGastada(environmentState.getEnergiaGastada()+costo);
            
        	VentanaPrincipal.updateEnerg�a(agState.getenergiaGastada());
        	VentanaPrincipal.updateLocacionDrone(agState.getlocacion());
        	VentanaPrincipal.writeConsole("Acci�n ejecutada: MoverLocacionO\n\n","Acci�n");
            return environmentState;
        }

        return null;
    }

    /**
     * This method returns the action cost.
     */
    @Override
    public Double getCost() {
        return new Double(COSTO_MOVERSE);
    }

    /**
     * This method is not important for a search based agent, but is essensial
     * when creating a calculus based one.
     */
    @Override
    public String toString() {
        return "MoverLocacionO";
    }
}