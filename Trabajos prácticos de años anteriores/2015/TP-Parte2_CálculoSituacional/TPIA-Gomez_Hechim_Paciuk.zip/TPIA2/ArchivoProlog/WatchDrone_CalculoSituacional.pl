% Autor: G�mez, Hechim, Paciuk - Grupo 11
% Fecha: 14/06/2015

:- dynamic hayVictimario/2,visitada/1,energia/2,cantidadVictimarios/2,posicion/3,direccionVictimario/10,executedAction/2.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                          Reglas de Diagnostico                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hayVictimario(Esq,S):- perception(_,_,_,_,_,_,_,_,1,Xpos,Ypos),esquina(Esq,Xpos,Ypos),actualSituation(S).

direccionVictimario(N,NE,E,SE,Su,SO,O,NO,PosAct,S):- perception(N,NE,E,SE,Su,SO,O,NO,PosAct,_,_),actualSituation(S).

posicion(Xpos,Ypos,S):- perception(_,_,_,_,_,_,_,_,_,Xpos,Ypos),actualSituation(S).

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           Reglas Causales                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Axiomas de Posibilidad                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

posible(identificarVictimario,S):- posicion(Xpos,Ypos,S), esquina(Esq,Xpos,Ypos),hayVictimario(Esq,S).

posible(moverLocacionN,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,norte),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionNE,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,norEste),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionE,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,este),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionSE,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,surEste),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionS,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,sur),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionSO,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,surOeste),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionO,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,oeste),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).
posible(moverLocacionNO,S):- posicion(Xpos,Ypos,S),esquina(Esq1,Xpos,Ypos),adyacente(Esq1,Esq2,norOeste),energia(EDisp,S),costo(Esq2,C),EDisp >= C,not(visitada(Esq2)).


%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Axiomas de Estado Sucesor                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Mantiene de situaci�n en situaci�n si hayVictimario en una esquina.
est(S1) :-
    S1 > 0, S is S1-1,
    hayVictimario(Esq,S),
    asserta(hayVictimario(Esq,S1)).

% Aumenta de situaci�n en situaci�n la cantidadVictimarios si se identific� un victimario en la �ltima acci�n.
est(S1) :-
    S1 > 0, S is S1-1,
    cantidadVictimarios(N,S),
    not(executedAction(identificarVictimario,S)),
    asserta(cantidadVictimarios(N,S1)).

% Mantiene de situaci�n en situaci�n la cantidadVictimarios si no se identific� un victimario en la �ltima acci�n.
est(S1) :-
    S1 > 0, S is S1-1,
    cantidadVictimarios(N,S),
    N1 is N + 1,
    executedAction(identificarVictimario,S),
    asserta(cantidadVictimarios(N1,S1)).

% Si se mueve que cambie de posicion
est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,norte),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionN,S),
    asserta(posicion(Xpos1,Ypos1,S1)).
    
est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,norEste),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionNE,S),
    asserta(posicion(Xpos1,Ypos1,S1)).

est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,este),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionE,S),
    asserta(posicion(Xpos1,Ypos1,S1)).
    
est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,surEste),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionSE,S),
    asserta(posicion(Xpos1,Ypos1,S1)).

est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,sur),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionS,S),
    asserta(posicion(Xpos1,Ypos1,S1)).
    
est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,surOeste),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionSO,S),
    asserta(posicion(Xpos1,Ypos1,S1)).
    
est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,oeste),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionO,S),
    asserta(posicion(Xpos1,Ypos1,S1)).

 est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    adyacente(Esq,Esq1,norOeste),
    esquina(Esq1,Xpos1,Ypos1),
    executedAction(moverLocacionNO,S),
    asserta(posicion(Xpos1,Ypos1,S1)).

% Si no se mueve, mantiene la posici�n
 est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    executedAction(identificarVictimario,S),
    asserta(posicion(Xpos,Ypos,S1)).

% Disminuye de situaci�n en situaci�n la energ�a disponible cuando la �ltima acci�n ejecutada fue de movimiento.
 est(S1) :-
    S1 > 0, S is S1-1,
    energia(E,S),
    posicion(Xpos,Ypos,S1),
    esquina(Esq,Xpos,Ypos),
    costo(Esq,Costo),
    not(executedAction(identificarVictimario,S)),
    E1 is E - Costo,
    asserta(energia(E1,S1)).

% Mantiene de situaci�n en situaci�n la energ�a disponible cuando la �ltima acci�n ejecutada fue identificarVictimario.
est(S1) :-
    S1 > 0, S is S1-1,
    energia(E,S),
    executedAction(identificarVictimario,S),
    asserta(energia(E,S1)).

% Marca como visitada la esquina a la cual se movi� el agente.
 est(S1) :-
    S1 > 0, S is S1-1,
    posicion(Xpos,Ypos,S),
    esquina(Esq,Xpos,Ypos),
    posicion(Xpos1,Ypos1,S1),
    esquina(Esq1,Xpos1,Ypos1),
    Esq \= Esq1,
    asserta(visitada(Esq1)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                      Evaluacion de las Acciones                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 excelent(identificarVictimario,S):- posible(identificarVictimario,S).
 very_good(moverLocacionN,S):- direccionVictimario(1,_,_,_,_,_,_,_,_,S),posible(moverLocacionN,S).
 very_good(moverLocacionNE,S):- direccionVictimario(_,1,_,_,_,_,_,_,_,S),posible(moverLocacionNE,S).
 very_good(moverLocacionE,S):- direccionVictimario(_,_,1,_,_,_,_,_,_,S),posible(moverLocacionE,S).
 very_good(moverLocacionSE,S):- direccionVictimario(_,_,_,1,_,_,_,_,_,S),posible(moverLocacionSE,S).
 very_good(moverLocacionS,S):- direccionVictimario(_,_,_,_,1,_,_,_,_,S),posible(moverLocacionS,S).
 very_good(moverLocacionSO,S):- direccionVictimario(_,_,_,_,_,1,_,_,_,S),posible(moverLocacionSO,S).
 very_good(moverLocacionO,S):- direccionVictimario(_,_,_,_,_,_,1,_,_,S),posible(moverLocacionO,S).
 very_good(moverLocacionNO,S):- direccionVictimario(_,_,_,_,_,_,_,1,_,S),posible(moverLocacionNO,S).
 good(moverLocacionN,S):- direccionVictimario(0,_,_,_,_,_,_,_,_,S),posible(moverLocacionN,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,norte),potencia(Esq1,N),N > 0.
 good(moverLocacionNE,S):- direccionVictimario(_,0,_,_,_,_,_,_,_,S),posible(moverLocacionNE,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,norEste),potencia(Esq1,N),N > 0.
 good(moverLocacionE,S):- direccionVictimario(_,_,0,_,_,_,_,_,_,S),posible(moverLocacionE,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,este),potencia(Esq1,N),N > 0.
 good(moverLocacionSE,S):- direccionVictimario(_,_,_,0,_,_,_,_,_,S),posible(moverLocacionSE,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,surEste),potencia(Esq1,N),N > 0.
 good(moverLocacionS,S):- direccionVictimario(_,_,_,_,0,_,_,_,_,S),posible(moverLocacionS,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,sur),potencia(Esq1,N),N > 0.
 good(moverLocacionSO,S):- direccionVictimario(_,_,_,_,_,0,_,_,_,S),posible(moverLocacionSO,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,surOeste),potencia(Esq1,N),N > 0.
 good(moverLocacionO,S):- direccionVictimario(_,_,_,_,_,_,0,_,_,S),posible(moverLocacionO,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,oeste),potencia(Esq1,N),N > 0.
 good(moverLocacionNO,S):- direccionVictimario(_,_,_,_,_,_,_,0,_,S),posible(moverLocacionNO,S),posicion(Xpos,Ypos,S),esquina(Esq,Xpos,Ypos),adyacente(Esq,Esq1,norOeste),potencia(Esq1,N),N > 0.
 regular(moverLocacionN,S):- posible(moverLocacionN,S).
 regular(moverLocacionNE,S):- posible(moverLocacionNE,S).
 regular(moverLocacionE,S):- posible(moverLocacionE,S).
 regular(moverLocacionSE,S):- posible(moverLocacionSE,S).
 regular(moverLocacionS,S):- posible(moverLocacionS,S).
 regular(moverLocacionSO,S):- posible(moverLocacionSO,S).
 regular(moverLocacionO,S):- posible(moverLocacionO,S).
 regular(moverLocacionNO,S):- posible(moverLocacionNO,S).


 bestAction(noAction,S):- goalReached(S),!.
 bestAction(X,S):- excelent(X,S),!.
 bestAction(X,S):- very_good(X,S),!.
 bestAction(X,S):- good(X,S),!.
 bestAction(X,S):- regular(X,S),!.

 goalReached(S):- cantidadVictimarios(N,S), N > 0.
 
%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                          Sentencias Extra                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                      Informacion del escenario                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        Predicados Auxiliares                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Esta funcion se encarga de calcular el costo de moverse a una esquina.
costo(Esq,1):- potencia(Esq,Pot), Pot > 0.
costo(Esq,2):- potencia(Esq,Pot), Pot is 0.

%%

