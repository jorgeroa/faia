
package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.faia.agent.Action;
import frsf.cidisi.faia.agent.NoAction;
import frsf.cidisi.faia.agent.Perception;
import frsf.cidisi.faia.agent.situationcalculus.SituationCalculusBasedAgent;
import frsf.cidisi.faia.exceptions.PrologConnectorException;
import frsf.cidisi.faia.solver.situationcalculus.SituationCalculus;

public class DroneAgent extends SituationCalculusBasedAgent {

    private Action lastAction = NoAction.getInstance();

    public DroneAgent() throws PrologConnectorException {
        this.setAgentState(new DroneAgentState());
    }

    @Override
    public void tell(Action action) {
        DroneAgentState kb = this.getAgentState();
        kb.tell(action);
    }

    @Override
    public void see(Perception p) {
        this.getAgentState().updateState(p);
    }

    @Override
    public Action selectAction() {
        this.setSolver(new SituationCalculus());

        Action selectedAction = null;
        try {
            selectedAction = this.getSolver().solve(new Object[]{this.getAgentState()});
        } catch (Exception e) {
            e.printStackTrace();
        }

        this.lastAction = selectedAction;
        
        //TODO: notificar interfaz
        
        return selectedAction;
    }

    @Override
    public DroneAgentState getAgentState() {
        DroneAgentState agentState = (DroneAgentState) super.getAgentState();

        return agentState;
    }

    public Action getLastAction() {
        return this.lastAction;
    }
}
