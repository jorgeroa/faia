package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.faia.agent.Action;
import frsf.cidisi.faia.agent.ActionFactory;

import frsf.cidisi.exercise.drone2.situationCalculus.actions.*;



public class DroneAgentActionFactory extends ActionFactory {

    private static DroneAgentActionFactory instance;

    private DroneAgentActionFactory() {
    }

    public static DroneAgentActionFactory getInstance() {
        if (instance == null) {
            instance = new DroneAgentActionFactory();
        }
        return instance;
    }

    @Override
    protected String endActionString() {
        return "noAction";
    }

     @Override
   	 protected Action stringToAction(String stringAction) {
        Action actionObject = null;
        //TODO: notificar interfaz
	if (stringAction.equals("identificarVictimario")) {
            actionObject = new IdentificarVictimario();
        } else if (stringAction.equals("moverLocacionN")) {
            actionObject = new MoverLocacionN();
        } else if (stringAction.equals("moverLocacionNE")) {
            actionObject = new MoverLocacionNE();
        } else if (stringAction.equals("moverLocacionE")) {
            actionObject = new MoverLocacionE();
        } else if (stringAction.equals("moverLocacionSE")) {
            actionObject = new MoverLocacionSE();
        } else if (stringAction.equals("moverLocacionS")) {
            actionObject = new MoverLocacionS();
        } else if (stringAction.equals("moverLocacionSO")) {
            actionObject = new MoverLocacionSO();
        } else if (stringAction.equals("moverLocacionO")) {
            actionObject = new MoverLocacionO();
        } else if (stringAction.equals("moverLocacionNO")) {
            actionObject = new MoverLocacionNO();

        }
        
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	
        return actionObject;
    }
}
