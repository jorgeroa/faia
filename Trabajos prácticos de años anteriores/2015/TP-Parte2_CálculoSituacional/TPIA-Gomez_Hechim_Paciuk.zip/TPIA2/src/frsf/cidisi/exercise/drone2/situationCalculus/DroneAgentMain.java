package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.exercise.drone2.situationCalculus.DroneAgentState;
import frsf.cidisi.faia.exceptions.PrologConnectorException;
import frsf.cidisi.faia.simulator.SituationCalculusBasedAgentSimulator;

public class DroneAgentMain {

    /**
     * @param args
     * @throws PrologConnectorException
     */
    public static boolean main(String[] args) throws PrologConnectorException {
        
        DroneAgent agent = new DroneAgent();
        DroneEnvironment environment = new DroneEnvironment();

        SituationCalculusBasedAgentSimulator simulator =
                new SituationCalculusBasedAgentSimulator(environment, agent);

        simulator.start();
        
        //TODO: notificar interfaz
        
        return ((DroneAgentState)agent.getAgentState()).getciudad().getVisitada() 
		|| ((DroneAgentState)agent.getAgentState()).getvictimariosEncontrados() > 0;
    }
}
