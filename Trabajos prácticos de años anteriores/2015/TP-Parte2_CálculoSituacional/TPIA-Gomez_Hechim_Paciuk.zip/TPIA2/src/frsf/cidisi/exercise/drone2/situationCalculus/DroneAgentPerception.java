package frsf.cidisi.exercise.drone2.situationCalculus;

import java.util.ArrayList;
import java.util.List;

import logica.Esquina;
import logica.Locacion;
import logica.Posicion;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneAgent;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneEnvironment;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneEnvironmentState;
import frsf.cidisi.faia.agent.Agent;
import frsf.cidisi.faia.agent.situationcalculus.SituationCalculusPerception;
import frsf.cidisi.faia.environment.Environment;

public class DroneAgentPerception extends SituationCalculusPerception {

	private Posicion gps;
	private boolean[] camara;	

    public DroneAgentPerception() {
    	gps = new Posicion();
    	camara = new boolean[9];
    }

    @Override
    public void initPerception(Agent agentIn, Environment environmentIn) {
    	DroneAgent agent = (DroneAgent) agentIn;
        DroneEnvironment environment = (DroneEnvironment) environmentIn;
        DroneEnvironmentState environmentState = environment.getEnvironmentState();
        
        Locacion locIn = agent.getAgentState().getlocacion();
        for(Locacion l : environmentState.getciudad().getSublocaciones()) // l = cuadrante
        	for(int i=0;i < l.getSublocaciones().size();i++) // l.getSublocacion(i) = subcuadrante
        		for(Locacion k: (l.getSublocaciones()).get(i).getSublocaciones())
        			if(k.getNombre().compareTo(locIn.getNombre()) == 0)
        				environmentState.setlocacionDrone(k);
        Locacion locacionDrone = environmentState.getlocacionDrone();
        int alturaDrone = locacionDrone.calcularAltura();
        
        //Percepcion del gps
        gps.setX((int)locacionDrone.getCentro().getX());
        gps.setY((int)locacionDrone.getCentro().getY());
        gps.setZ(alturaDrone);
        
      
        //Percepcion de la camara
        if(alturaDrone == 3){
        	for(int i=0; i<8; i++){
        		camara[i] = ((Esquina)locacionDrone).hayVictimario(i);
        	}
        	camara[8] = ((Esquina)locacionDrone).hayCriminal();
        }
    }

    @Override
    public String toString() {
        StringBuffer string = new StringBuffer("perception(");
        for(int i=0;i<9;i++){
        	if(this.camara[i])
        		string.append("1");
        	else
        		string.append("0");
        	string.append(",");
        }
        string.append(gps.getX());
        string.append(",");
        string.append(gps.getY());
        string.append(")");

        return string.toString();
    }
    
    
     public Posicion getgps(){
        return gps;
     }
     public void setgps(Posicion arg){
        this.gps = arg;
     }
     public boolean[] getcamara(){
        return camara;
     }
     public void setcamara(boolean[] arg){
        this.camara = arg;
     }


}
