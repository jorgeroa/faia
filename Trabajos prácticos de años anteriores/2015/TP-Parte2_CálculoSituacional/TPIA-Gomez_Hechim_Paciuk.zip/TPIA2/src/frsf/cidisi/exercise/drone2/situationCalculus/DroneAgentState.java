package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.faia.agent.ActionFactory;
import frsf.cidisi.faia.agent.Perception;
import frsf.cidisi.faia.agent.situationcalculus.KnowledgeBase;
import frsf.cidisi.faia.agent.situationcalculus.SituationCalculusPerception;
import frsf.cidisi.faia.exceptions.PrologConnectorException;
import interfaz.VentanaPrincipal;

import java.util.Hashtable;
import java.util.List;

import logica.Esquina;
import logica.Locacion;

public class DroneAgentState extends KnowledgeBase {
	
	private Locacion ciudad;
    private int energiaInicial;
    private int energiaGastada;
    private Locacion locacion;
    private boolean[] direccionVictimario;
    private int victimariosEncontrados;

	public DroneAgentState() throws PrologConnectorException {
 
        super("ArchivoProlog/WatchDrone_CalculoSituacional.pl");
        
        ciudad = new Locacion();
		energiaInicial = 0;
		energiaGastada = 0;
		locacion = new Locacion();
		direccionVictimario = new boolean[9];
		for(int i=0;i<9;i++) 
			direccionVictimario[i]=false;
		victimariosEncontrados = 0;
		
        this.initState();
    }

    @Override
    public ActionFactory getActionFactory() {
        return DroneAgentActionFactory.getInstance();
    }

    @Override
    public String getSituationPredicate() {
        return "actualSituation";
    }

    @Override
    public String getBestActionPredicate() {
        return "bestAction";
    }

    @Override
    public String getExecutedActionPredicate() {
        return "executedAction";
    }

    @Override
    public void updateState(Perception p) {
    	if(((DroneAgentPerception)p).getcamara()[8] == true)
    		((Esquina) locacion).setCriminal(true);
        this.tell((SituationCalculusPerception) p);
        VentanaPrincipal.writeConsole(toString(),"Titulada");
    }

    @Override
    public void initState() {
    	ciudad = VentanaPrincipal.getCiudadSemiVacia();
		energiaInicial = 1000 ;
		//TODO en caso de tener 2 cuadrantes para esa esquina, preguntar con que cuadrante ejecutar
		Locacion locAux = VentanaPrincipal.getEsquinaInicialDrone();
		locacion = ciudad.buscarLocacion((int)locAux.getCentro().getX(),(int)locAux.getCentro().getY(),
				(int)locAux.getPadre().getCentro().getX(),(int)locAux.getPadre().getCentro().getY(),2);

		List<Locacion> esquinasCuadrante = locacion.getPadre().getSublocaciones();
		String listaEsqs = "listaEsquinas([";
		for(Locacion e : esquinasCuadrante){
			listaEsqs += e.getNombre().toLowerCase() + ",";
		}
		//Saca la ultima coma 
		listaEsqs = listaEsqs.substring(0,listaEsqs.length()-1);
		listaEsqs += "])";
		this.addKnowledge(listaEsqs);
		
		//Seteamos las coordenadas de las esquinas en la base de conocimiento
		for(Locacion l : esquinasCuadrante){
			this.addKnowledge("esquina("+l.getNombre().toLowerCase()+","
					+(int)(l.getCentro().getX())+","+(int)(l.getCentro().getY())+")");
		}
		
		//seteamos las adyacencias
		String dir[] = {"norte","norEste","este","surEste","sur","surOeste","oeste","norOeste"};
		for(Locacion l : esquinasCuadrante){
			for(int i=0;i<8;i++){
				if(l.getAdyacente(i) != null)
			this.addKnowledge("adyacente("+l.getNombre().toLowerCase()+","
					+l.getAdyacente(i).getNombre().toLowerCase()+","+dir[i]+")");
			}
		}
		
		//seteamos las potencias de las esquinas
		for(Locacion l : esquinasCuadrante){
			this.addKnowledge("potencia("+l.getNombre().toLowerCase()+","+l.getSenial()+")");
		}
		
		this.addKnowledge("cantidadVictimarios(0,0)");
		
		this.addKnowledge("energia("+energiaInicial+",0)");
		
		this.addKnowledge("posicion("+(int)(locacion.getCentro().getX())+","+(int)(locacion.getCentro().getY())+",0)");
		this.addKnowledge("direccionVictimario(false,false,false,false,false,false,false,false,false,0)");
		
    }

    @Override
    public String toString() {
    	String str = "";
        
        str = str + "Estado del Drone:\n";//Ciudad:\n";
        
        //esquinas del subcuadrante del drone 
        for(Locacion l : locacion.getPadre().getSublocaciones()){ //cuadrantes
        	str = str + "(" + l.getNombre() + ": " + l.getSenial() + "),";
        }
        str += "\n";
        str = str + "\nEnergia Disponible: " + (energiaInicial - energiaGastada);
        str = str + "\nVictimarios Encontrados: " + victimariosEncontrados;
        str = str + "\nLocacion Actual: " + locacion.getNombre();
        /*str = str + "\nDireccion Victimario: ";
    	str = str + "N: " + direccionVictimario[0]
    	          + "; NE: " + direccionVictimario[1]
    	          + "; E: " + direccionVictimario[2]
    	          + "; SE: " + direccionVictimario[3]
    	          + "; S: " + direccionVictimario[4]
    	          + "; SO: " + direccionVictimario[5]
    	          + "; O: " + direccionVictimario[6]
    	          + "; NO: " + direccionVictimario[7]
    	          + "; ESQUINA ACTUAL: " + direccionVictimario[8] + ";\n";*/
       
        return str;
    }
    
    public Locacion getciudad() {
		return ciudad;
	}

	public void setciudad(Locacion ciudad) {
		this.ciudad = ciudad;
	}

	public int getenergiaInicial() {
		return energiaInicial;
	}

	public void setenergiaInicial(int energiaInicial) {
		this.energiaInicial = energiaInicial;
	}

	public int getenergiaGastada() {
		return energiaGastada;
	}

	public void setenergiaGastada(int energiaGastada) {
		this.energiaGastada = energiaGastada;
	}

	public Locacion getlocacion() {
		return locacion;
	}

	public void setlocacion(Locacion locacion) {
		this.locacion = locacion;
	}

	public boolean[] getdireccionVictimario() {
		return direccionVictimario;
	}

	public void setdireccionVictimario(boolean[] direccionVictimario) {
		this.direccionVictimario = direccionVictimario;
	}

	public int getvictimariosEncontrados() {
		return victimariosEncontrados;
	}

	public void setvictimariosEncontrados(int victimariosEncontrados) {
		this.victimariosEncontrados = victimariosEncontrados;
	}
    
}
