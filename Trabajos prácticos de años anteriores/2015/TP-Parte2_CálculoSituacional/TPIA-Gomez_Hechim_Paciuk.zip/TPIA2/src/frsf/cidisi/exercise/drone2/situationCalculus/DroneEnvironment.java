package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.exercise.drone2.situationCalculus.DroneAgentPerception;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneEnvironmentState;
import frsf.cidisi.faia.agent.Action;
import interfaz.VentanaPrincipal;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import logica.Esquina;
import logica.Locacion;
import logica.Posicion;
import frsf.cidisi.faia.agent.Agent;
import frsf.cidisi.faia.environment.Environment;


public class DroneEnvironment extends Environment {

    public DroneEnvironment() {
        this.environmentState = new DroneEnvironmentState();
    }

    @Override
    public DroneEnvironmentState getEnvironmentState() {
        return (DroneEnvironmentState) super.getEnvironmentState();
    }

    @Override
    public boolean agentFailed(Action action) {

    	DroneEnvironmentState envState = this.getEnvironmentState();
        
        int agentEnergy = 1000 - envState.getEnergiaGastada();

        if (agentEnergy <= 0)
        	return true;

        return false;
    }

    @Override
    public DroneAgentPerception getPercept() {        
        DroneAgentPerception perception = new DroneAgentPerception();
		
        DroneEnvironmentState est = (DroneEnvironmentState) environmentState;
        //gps
        Posicion pos =new Posicion();
        pos.setX((int)est.getlocacionDrone().getCentro().getX());
        pos.setY((int)est.getlocacionDrone().getCentro().getY());
        pos.setZ(est.getlocacionDrone().calcularAltura());
        perception.setgps(pos);
        //camara
        boolean[] cam = new boolean[9];
        if(est.getlocacionDrone().calcularAltura() == 3){
        	for(int i=0; i<8; i++)
        		cam[i] = ((Esquina) est.getlocacionDrone()).hayVictimario(i);
        	
        	cam[8] = ((Esquina)est.getlocacionDrone()).hayCriminal();
        }
        else{
        	for(int i=0;i<9;i++)
        		cam[i]=false;
        }
        perception.setcamara(cam);
        VentanaPrincipal.writeConsole(perception.toString(),"Titulada");
        
        return perception;
    }
    
    @Override
    public String toString() {
        return this.environmentState.toString();
    }
}
