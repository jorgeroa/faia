package frsf.cidisi.exercise.drone2.situationCalculus;

import frsf.cidisi.faia.state.EnvironmentState;
import interfaz.VentanaPrincipal;

import logica.Locacion;

public class DroneEnvironmentState extends EnvironmentState {

	
    private Locacion ciudad;
    private Locacion locacionDrone;
    private int energiaGastada;
	
	
    public DroneEnvironmentState() {
    	
		ciudad = new Locacion();
		locacionDrone = new Locacion();
		energiaGastada = 0;
   
    this.initState();
}

    @Override
    public void initState() {
    	energiaGastada = 0;
    	ciudad = VentanaPrincipal.getCiudad();
    	Locacion aux = VentanaPrincipal.getEsquinaInicialDrone();
        locacionDrone = ciudad.buscarLocacion((int)aux.getCentro().getX(), (int)aux.getCentro().getY(), 
        		(int)aux.getPadre().getCentro().getX(), (int)aux.getPadre().getCentro().getY(), 2);        
    }


    @Override
    public String toString() {
    	 String str = "";
         str = str + "Estado del Ambiente:\n";
         str = str + "Posicion Drone: " + locacionDrone.getNombre() + "\n";
         
         for(Locacion l : locacionDrone.getPadre().getSublocaciones()){ //Esquinas del cuadrante
         	str = str + "Intesidad en " + l.getNombre() + ": " + l.getSenial() + "\n";
         }
         str += "\n";
         
         return str;
    }
   	
     public Locacion getciudad(){
        return ciudad;
     }
     public void setciudad(Locacion arg){
        ciudad = arg;
     }
     public Locacion getlocacionDrone(){
        return locacionDrone;

     }
     public void setlocacionDrone(Locacion arg){
        locacionDrone = arg;
     }
     public int getEnergiaGastada(){
        return energiaGastada;
     }
     public void setEnergiaGastada(int arg){
        energiaGastada = arg;
     }

    
}
