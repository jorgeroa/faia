package frsf.cidisi.exercise.drone2.situationCalculus.actions;

import interfaz.VentanaPrincipal;
import logica.Esquina;
import logica.Locacion;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneAgentState;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneEnvironmentState;
import frsf.cidisi.faia.agent.situationcalculus.SituationCalculusAction;
import frsf.cidisi.faia.state.AgentState;
import frsf.cidisi.faia.state.EnvironmentState;

public class MoverLocacionSO extends SituationCalculusAction {

	private int COSTO_MOVERSE = 1;
	
    @Override
    public EnvironmentState execute(AgentState ast, EnvironmentState est) {
        
    	DroneEnvironmentState environmentState = (DroneEnvironmentState) est;
        DroneAgentState agState = ((DroneAgentState) ast);

        if(agState.getlocacion().getAdyacente(Locacion.SUROESTE) != null 
        		&& ((agState.getlocacion().getAdyacente(Locacion.SUROESTE).getSenial() > 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= COSTO_MOVERSE)
      		   || (agState.getlocacion().getAdyacente(Locacion.SUROESTE).getSenial() == 0 && (agState.getenergiaInicial() - agState.getenergiaGastada()) >= 2*COSTO_MOVERSE))){
        	agState.setlocacion(agState.getlocacion().getAdyacente(Locacion.SUROESTE));
        	int costo = COSTO_MOVERSE;
        	if(agState.getlocacion().getSenial()==0)
        		costo *= 2;
        	agState.setenergiaGastada(agState.getenergiaGastada()+costo);
        	agState.getlocacion().increasePasadas();
        	agState.getlocacion().setVisitada(true);
        	
        	environmentState.setlocacionDrone(environmentState.getlocacionDrone().getAdyacente(Locacion.SUROESTE));
        	environmentState.setEnergiaGastada(environmentState.getEnergiaGastada()+costo);
            
        	VentanaPrincipal.updateEnerg�a(agState.getenergiaGastada());
        	VentanaPrincipal.updateLocacionDrone(agState.getlocacion());
        	VentanaPrincipal.writeConsole("Acci�n ejecutada: MoverLocacionSO\n\n","Acci�n");
            return environmentState;
        }

        return null;
    }

    @Override
    public String toString() {
        return "moverLocacionSO";
    }
}

