package interfaz;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class PanelResultado extends JPanel {

	private static final long serialVersionUID = -4109378068527397236L;
	private boolean state;
	
	public PanelResultado(boolean isPositiveState){
		state = isPositiveState;
	}
	
	public void paint (Graphics g){
		//super.paint(g);
		Dimension tamanio = getSize();
		setOpaque(false);

		//Dibujamos el mapa
		ImageIcon imagenFondo; 
		if(state)
			imagenFondo = new ImageIcon(getClass().getResource("/imagenes/AtrapaVictimario.gif"));
		else
			imagenFondo = new ImageIcon(getClass().getResource("/imagenes/VictimarioEscapa.gif"));
		g.drawImage(imagenFondo.getImage(),0,0,tamanio.width,tamanio.height, null);
	}

}
