package logica;

import interfaz.VentanaPrincipal;
import frsf.cidisi.exercise.drone2.situationCalculus.DroneAgentMain;
import frsf.cidisi.faia.exceptions.PrologConnectorException;

public class HiloSimulador extends Thread {

	int estrategia;
	
	public void run(){
		try {
			String aux[] = {""};
			boolean exito = DroneAgentMain.main(aux);
			if(exito)
				VentanaPrincipal.writeConsole("WatchDrone ha atrapado al victimario que aterrorizaba la ciudad!!! :D","Titulada");
			else
				VentanaPrincipal.writeConsole("WatchDrone no ha logrado alcanzar su meta... :(","Titulada");
			VentanaPrincipal.mostrarEstadoFinal(exito);
		} catch (PrologConnectorException e) {
			e.printStackTrace();
		}
	}
	
	public void setEstrategia(int strategy){
		estrategia = strategy;
	}
	
}
