package logica;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Locacion {
	
	protected Locacion padre;
	protected List<Locacion> sublocaciones;
	protected Locacion[] adyacentes;
	protected Point centro;
	protected int valorSenial;
	protected String nombre;
	protected int cantPasadas;
	public final static int NORTE = 0;
	public final static int NORESTE = 1;
	public final static int ESTE = 2;
	public final static int SURESTE = 3;
	public final static int SUR = 4;
	public final static int SUROESTE = 5;
	public final static int OESTE = 6;
	public final static int NOROESTE = 7;
	
	public Locacion(){
		sublocaciones = new ArrayList<Locacion>();
		adyacentes = new Locacion[8];
		centro = new Point();
		valorSenial = 0;
		cantPasadas = 0;
		nombre = "";
	}
	
	public Locacion(String nomb){
		sublocaciones = new ArrayList<Locacion>();
		adyacentes = new Locacion[8];
		centro = new Point();
		valorSenial = 0;
		nombre = nomb;
		cantPasadas = 0;
	}
	
	public Locacion(int x, int y, String nomb, Locacion padre){
		sublocaciones = new ArrayList<Locacion>();
		adyacentes = new Locacion[8];
		centro = new Point(x,y);
		setCentro(x,y);
		valorSenial = 0;
		nombre = nomb;
		cantPasadas = 0;
		centro.setLocation(x,y);
		this.padre = padre;
	}
	
	public void addSublocacion(Locacion l){
		l.setPadre(this);
		sublocaciones.add(l);
	}
	
	public void addAdyacente(Locacion l, int direccion){
		if(direccion >= 0 && direccion <= 7)
			adyacentes[direccion]= l;
		//else tirar excepcion
	}
	
	public Locacion getAdyacente(int dir){
		return adyacentes[dir];
	}
	
	public List<Locacion> getAdyacentes(){
		List<Locacion> locaciones = new ArrayList<Locacion>();
		for(Locacion l: adyacentes)
			if(l != null)
				locaciones.add(l);
		return locaciones;
	}
	
	public void actualizarEsquina(double d,double e,int cantPersonas){
		for(Locacion l : getSublocaciones())
			l.actualizarEsquina(d, e, cantPersonas);
	}
	
	public void setPadre(Locacion lp){
		padre = lp;
	}
	
	public Locacion getPadre(){
		return padre;
	}
	
	public boolean getVisitada(){
		boolean allVisited = true;
		for(Locacion l : getSublocaciones())
			allVisited = allVisited && l.getVisitada();
		return allVisited;
	}
	
	public void setVisitada(boolean val){
		for(Locacion l : getSublocaciones())
			l.setVisitada(val);
	}
	
	public void increasePasadas(){
		//Solo incrementara en las esquinas
		cantPasadas++;
	}
	
	public int getPasadas(){
		return cantPasadas;
	}
	
	public void setPasadas(int p){
		cantPasadas = p;
	}
	
	public int calcularAltura(){
		if(padre == null)
			return 0;
		else
			return 1 + padre.calcularAltura();
	}
	
	public Point getCentro(){
		return centro;
	}
	
	public void setCentro(int x,int y){
		centro.setLocation(x,y);
	}
	
	public List<Locacion> getSublocaciones(){
		return sublocaciones;
	}
	
	public int getSenial(){
		return valorSenial;
	}
	
	public void setSenial(int val){
		valorSenial = val;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Locacion clone(Locacion parent){
		Locacion locacion = new Locacion();
		for(Locacion l : sublocaciones){
			locacion.addSublocacion(l.clone(locacion));
		}
		locacion.setPadre(parent);
		//
		//if(parent!=null)
			for(Locacion sl : getSublocaciones()){//Mis sublocaciones
				for(int i=0;i<8;i++){//Itero sobre los adyacentes de mis hijos
					if(sl.getAdyacente(i)!=null){//Si encuentro que tiene un ayacente
						Locacion foco = null;
						Locacion adya = null;
						for(Locacion slc : locacion.getSublocaciones()){
							if(slc.getCentro().getX() == sl.getCentro().getX()
									&& slc.getCentro().getY() == sl.getCentro().getY()){
								//Es la locacion que tiene un adyacente
								foco = slc;
							}
							else if(slc.getCentro().getX() == sl.getAdyacente(i).getCentro().getX()
									&& slc.getCentro().getY() == sl.getAdyacente(i).getCentro().getY()){
								//Es la locacion que es adyacente a la enfocada, y debe linkearse
								adya = slc;
							}
						}
						foco.addAdyacente(adya,i);
					}
				}
				
			}
		//
		locacion.setCentro((int) getCentro().getX(),(int) getCentro().getY());
		locacion.setSenial(getSenial());
		locacion.setNombre(getNombre());
		locacion.setPasadas(getPasadas());
		return locacion;
	}
	
	public Locacion buscarLocacion(int x, int y, int xp, int yp, int zp){
		Locacion a= null;
		a=busLocAux(x, y, xp, yp, zp, 0);
		return a;		
	}
	
	public Locacion getLocacionBajada(){
		for(Locacion l : getSublocaciones())
			if(l.getCentro().getX() == getCentro().getX() && l.getCentro().getY() == getCentro().getY())
				return l;
		return null;
	}
	
	private Locacion busLocAux(int x, int y, int xp, int yp, int zp, int nivActual){
		Locacion locacion = null;
		if(zp == nivActual){
			if(getCentro().getX() == xp && getCentro().getY() == yp){
				for(Locacion lo : getSublocaciones())
					if(lo.getCentro().getX() == x && lo.getCentro().getY() == y){
						locacion = lo;
					    break;
					}
			}
		}
		else{
			for(Locacion l : getSublocaciones()){
				Locacion aux = l.busLocAux(x, y, xp, yp, zp, nivActual + 1);
				if (aux!= null)
					locacion = aux;
			}
		}
		return locacion;
	}
	
	@Override
	public boolean equals(Object obj){	
		boolean res = true;

		Locacion loc = (Locacion) obj;
		
		res = res && (loc.getSenial() == valorSenial);
		res = res && (loc.getCentro().getX() == centro.getX() && loc.getCentro().getY() == centro.getY());
		res = res && (loc.getNombre().equals(this.nombre));
		for(int i=0;i < loc.getSublocaciones().size();i++){
			res = res && loc.getSublocaciones().get(i).equals(sublocaciones.get(i));
		}
		return res;
	}
	
	public void vaciar(){
		valorSenial = 0;
		for(Locacion l : sublocaciones)
			l.vaciar();
	}
	
	public void limpiarVictimario(){
		for(Locacion l : sublocaciones)
			l.limpiarVictimario();
	}
	
	public void calcularSeniales(){// alto: 10*X, medio: 20*X, bajo: X
		for(int i=0;i<sublocaciones.size();i++){//cada cuadrante
			int personas = 0;
			for(int j=0;j<getSublocaciones().get(i).getSublocaciones().size();j++){//cada subcuadrante
				int personasSC = 0;
				for(int k=0;k<sublocaciones.get(i).getSublocaciones().get(j).getSublocaciones().size();k++)//suma la cantidad de personas en las esquinas
					personasSC +=sublocaciones.get(i).getSublocaciones().get(j).getSublocaciones().get(k).getSenial();
				sublocaciones.get(i).getSublocaciones().get(j).setSenial(20*personasSC);
				personas+=personasSC;
			}
			sublocaciones.get(i).setSenial(10*personas);
		}
	}
	
	//Solo se ejcuta para la location ciudad
	public void setVisitadaEsquinaMelliza(boolean val,int x,int y){
		for(Locacion l : getSublocaciones())
				l.setVisitadaEsquinaMelliza(val,x,y);
	}
	
	public void setSenialEsquinaMelliza(int senial,int x,int y){
		for(Locacion l : getSublocaciones())
			l.setSenialEsquinaMelliza(senial,x,y);
	}
	
	public void setCriminalEsquinaMelliza(boolean val,int x,int y){
		for(Locacion l : getSublocaciones())
			l.setCriminalEsquinaMelliza(val,x,y);
	}
	
	public int calcSe�al(){
		int aux = 0;
		for(Locacion l: sublocaciones){
			aux += l.calcSe�al();
		}
		return aux;
	}
	public void marcarVisitEsqDir(int dir){
		if(this.getAdyacente(dir) != null){
			this.getAdyacente(dir).setVisitada(true);			
			this.getAdyacente(dir).marcarVisitEsqDir(dir);
		}
	}
}
